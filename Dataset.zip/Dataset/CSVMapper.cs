using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Linq;

public class CSVMapper : MonoBehaviour
{
  // Variabelen om bestandsnaam en -pad bij te houden
  private string fileName;
  private string filePath;
  private int cijfer;

  // Dictionary met landmark namen en headers
  private Dictionary<string, string> landmarkHeaderNames = new Dictionary<string, string>()
{
    { "Wrist", "wrist_x,wrist_y,wrist_z" },
    { "ThumbMetacarpal", "thumb_mcp_x,thumb_mcp_y,thumb_mcp_z" },
    { "ThumbProximal", "thumb_pip_x,thumb_pip_y,thumb_pip_z" },
    { "ThumbDistal", "thumb_dip_x,thumb_dip_y,thumb_dip_z" },
    { "ThumbTip", "thumb_tip_x,thumb_tip_y,thumb_tip_z" },
    { "IndexFingerMetacarpal", "index_mcp_x,index_mcp_y,index_mcp_z" },
    { "IndexFingerProximal", "index_pip_x,index_pip_y,index_pip_z" },
    { "IndexFingerDistal", "index_dip_x,index_dip_y,index_dip_z" },
    { "IndexFingerTip", "index_tip_x,index_tip_y,index_tip_z" },
    { "MiddleFingerMetacarpal", "middle_mcp_x,middle_mcp_y,middle_mcp_z" },
    { "MiddleFingerProximal", "middle_pip_x,middle_pip_y,middle_pip_z" },
    { "MiddleFingerDistal", "middle_dip_x,middle_dip_y,middle_dip_z" },
    { "MiddleFingerTip", "middle_tip_x,middle_tip_y,middle_tip_z" },
    { "RingFingerMetacarpal", "ring_mcp_x,ring_mcp_y,ring_mcp_z" },
    { "RingFingerProximal", "ring_pip_x,ring_pip_y,ring_pip_z" },
    { "RingFingerDistal", "ring_dip_x,ring_dip_y,ring_dip_z" },
    { "RingFingerTip", "ring_tip_x,ring_tip_y,ring_tip_z" },
    { "LittleFingerMetacarpal", "pinky_mcp_x,pinky_mcp_y,pinky_mcp_z" },
    { "LittleFingerProximal", "pinky_pip_x,pinky_pip_y,pinky_pip_z" },
    { "LittleFingerDistal", "pinky_dip_x,pinky_dip_y,pinky_dip_z" },
    { "LittleFingerTip", "pinky_tip_x,pinky_tip_y,pinky_tip_z" }
};

  private void Start()
  {
    // Maak een timestamp als onderdeel van de bestandsnaam
    string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

    // Stel bestandsnaam en -pad in
    fileName = "hand_coordinates_" + timestamp + ".csv";
    filePath = Path.Combine(Application.dataPath, "MediaPipeUnity", "Samples", "Scenes", "Hand Tracking", "NGT_Layer", "Dataset", fileName);

    // Als het bestand al bestaat, maak een nieuwe naam met een teller
    int fileCount = 0;
    while (File.Exists(filePath))
    {
      fileCount++;
      fileName = "hand_coordinates_" + timestamp + "_" + fileCount.ToString() + ".csv";
      filePath = Path.Combine(Application.dataPath, "MediaPipeUnity", "Samples", "Scenes", "Hand Tracking", "NGT_Layer", "Dataset", fileName);
    }

    // Maak het bestand aan en schrijf de header als het nog niet bestaat
    if (!File.Exists(filePath))
    {
      using (StreamWriter sw = File.CreateText(filePath))
      {
        // Maak een lijst met de headers voor elke landmark
        List<string> landmarkHeaders = new List<string>();
        foreach (var kvp in landmarkHeaderNames)
        {
          landmarkHeaders.Add(kvp.Value);
        }
        // Schrijf de header record naar het bestand
        sw.WriteLine("Time," + string.Join(",", landmarkHeaders) + ",cijfer");

      }
    }
  }

  private void Update()
  { // Maak een lijst met arrays van alle coördinaten per hand
    List<float[]> coordinatesList = new List<float[]>();

    // Loop door alle handen
    for (int i = 0; i < CoordinationMapper.Instance.HandLandmarks.Count; i++)

    { // Maak een array voor de coördinaten van deze hand
      float[] coordinates = new float[CoordinationMapper.Instance.HandLandmarks[i].LandmarkPositions.Count * 3];
      int index = 0;

      // Loop door alle landmarks van deze hand
      for (int j = 0; j < CoordinationMapper.Instance.HandLandmarks[i].LandmarkPositions.Count; j++)
      {
        // Voeg de coördinaten van de landmark toe aan de array
        Vector3 position = CoordinationMapper.Instance.HandLandmarks[i].LandmarkPositions[j].Position;
        coordinates[index] = position.x;
        coordinates[index + 1] = position.y;
        coordinates[index + 2] = position.z;
        index += 3;
      }
      // Voeg de array met coördinaten toe aan de lijst
      coordinatesList.Add(coordinates);
    }

    // Schrijf de coördinaten naar het bestand
    using (StreamWriter sw = File.AppendText(filePath))
    {
      // Voeg een timestamp toe aan elke rij
      float timeStamp = Time.realtimeSinceStartup;

      // Loop door alle handen en landmarks
      for (int i = 0; i < coordinatesList.Count; i++)
      {
        List<string> rowData = new List<string>();

        // Loop door alle landmarks van deze hand
        for (int j = 0; j < CoordinationMapper.Instance.HandLandmarks[i].LandmarkPositions.Count; j++)
        {
          // Voeg de naam en coördinaten van de landmark toe aan de rij
          
          Vector3 position = CoordinationMapper.Instance.HandLandmarks[i].LandmarkPositions[j].Position;
          string coordinatesString = string.Join(",", position.x, position.y, position.z);

          
          rowData.Add(coordinatesString);
        }

        cijfer = 1;

        // de landmark op 1 regel
        sw.WriteLine(timeStamp + "," + string.Join(",", rowData) + "," + cijfer);

      }
    }
  }
}
